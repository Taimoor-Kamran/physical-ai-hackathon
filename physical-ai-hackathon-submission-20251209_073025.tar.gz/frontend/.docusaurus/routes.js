import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/physical-ai-hackathon/blog',
    component: ComponentCreator('/physical-ai-hackathon/blog', '1a5'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/archive',
    component: ComponentCreator('/physical-ai-hackathon/blog/archive', '0bf'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/authors',
    component: ComponentCreator('/physical-ai-hackathon/blog/authors', '993'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/physical-ai-hackathon/blog/authors/all-sebastien-lorber-articles', '036'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/authors/yangshun',
    component: ComponentCreator('/physical-ai-hackathon/blog/authors/yangshun', '986'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/first-blog-post',
    component: ComponentCreator('/physical-ai-hackathon/blog/first-blog-post', 'd61'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/gazebo-tips',
    component: ComponentCreator('/physical-ai-hackathon/blog/gazebo-tips', '433'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/long-blog-post',
    component: ComponentCreator('/physical-ai-hackathon/blog/long-blog-post', 'f2b'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/mdx-blog-post',
    component: ComponentCreator('/physical-ai-hackathon/blog/mdx-blog-post', '80f'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/recent-posts',
    component: ComponentCreator('/physical-ai-hackathon/blog/recent-posts', '8c6'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/ros2-best-practices',
    component: ComponentCreator('/physical-ai-hackathon/blog/ros2-best-practices', '931'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags', '405'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/ai',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/ai', '85d'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/best-practices',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/best-practices', '684'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/development',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/development', '916'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/docusaurus',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/docusaurus', '27b'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/facebook',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/facebook', '40d'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/gazebo',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/gazebo', 'c99'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/hello',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/hello', 'fc0'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/hola',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/hola', '989'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/robotics',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/robotics', 'b45'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/ros-2',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/ros-2', '2c9'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/simulation',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/simulation', 'a71'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/tips',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/tips', '778'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/tags/welcome',
    component: ComponentCreator('/physical-ai-hackathon/blog/tags/welcome', 'c97'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/welcome',
    component: ComponentCreator('/physical-ai-hackathon/blog/welcome', 'fb8'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/blog/welcome',
    component: ComponentCreator('/physical-ai-hackathon/blog/welcome', 'f11'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/markdown-page',
    component: ComponentCreator('/physical-ai-hackathon/markdown-page', '630'),
    exact: true
  },
  {
    path: '/physical-ai-hackathon/docs',
    component: ComponentCreator('/physical-ai-hackathon/docs', '7ff'),
    routes: [
      {
        path: '/physical-ai-hackathon/docs',
        component: ComponentCreator('/physical-ai-hackathon/docs', '51d'),
        routes: [
          {
            path: '/physical-ai-hackathon/docs',
            component: ComponentCreator('/physical-ai-hackathon/docs', '01f'),
            routes: [
              {
                path: '/physical-ai-hackathon/docs/capstone',
                component: ComponentCreator('/physical-ai-hackathon/docs/capstone', 'df8'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/control-systems',
                component: ComponentCreator('/physical-ai-hackathon/docs/control-systems', '48d'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/dynamics',
                component: ComponentCreator('/physical-ai-hackathon/docs/dynamics', 'fe4'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/human-robot-interaction',
                component: ComponentCreator('/physical-ai-hackathon/docs/human-robot-interaction', '5d3'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/intro',
                component: ComponentCreator('/physical-ai-hackathon/docs/intro', '7bb'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/introduction',
                component: ComponentCreator('/physical-ai-hackathon/docs/introduction', '05e'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/kinematics',
                component: ComponentCreator('/physical-ai-hackathon/docs/kinematics', '637'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/localization-mapping',
                component: ComponentCreator('/physical-ai-hackathon/docs/localization-mapping', '831'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/manipulation',
                component: ComponentCreator('/physical-ai-hackathon/docs/manipulation', '422'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/nvidia-isaac',
                component: ComponentCreator('/physical-ai-hackathon/docs/nvidia-isaac', 'cd6'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/path-planning',
                component: ComponentCreator('/physical-ai-hackathon/docs/path-planning', '6df'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/perception',
                component: ComponentCreator('/physical-ai-hackathon/docs/perception', 'b5d'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/ros2-gazebo',
                component: ComponentCreator('/physical-ai-hackathon/docs/ros2-gazebo', '0ad'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/sensors-actuators',
                component: ComponentCreator('/physical-ai-hackathon/docs/sensors-actuators', '8eb'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-basics/congratulations',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-basics/congratulations', 'a2a'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-basics/create-a-blog-post',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-basics/create-a-blog-post', '231'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-basics/create-a-document',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-basics/create-a-document', 'e6f'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-basics/create-a-page',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-basics/create-a-page', 'a83'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-basics/deploy-your-site',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-basics/deploy-your-site', 'ce9'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-basics/markdown-features',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-basics/markdown-features', '895'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-extras/manage-docs-versions',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-extras/manage-docs-versions', '86b'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/tutorial-extras/translate-your-site',
                component: ComponentCreator('/physical-ai-hackathon/docs/tutorial-extras/translate-your-site', '823'),
                exact: true
              },
              {
                path: '/physical-ai-hackathon/docs/vla-models',
                component: ComponentCreator('/physical-ai-hackathon/docs/vla-models', '65c'),
                exact: true,
                sidebar: "docs"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/physical-ai-hackathon/',
    component: ComponentCreator('/physical-ai-hackathon/', 'c07'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
