export default [
  require("/home/taimoor/Hackathon/frontend/node_modules/infima/dist/css/default/default.css"),
  require("/home/taimoor/Hackathon/frontend/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/home/taimoor/Hackathon/frontend/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/home/taimoor/Hackathon/frontend/src/css/custom.css"),
];
