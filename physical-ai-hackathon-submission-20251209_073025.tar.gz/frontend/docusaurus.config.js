module.exports = { ...require("./docusaurus.config.ts"), baseUrl: "/physical-ai-hackathon/" };
